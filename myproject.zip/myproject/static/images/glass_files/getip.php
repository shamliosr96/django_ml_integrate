myexternalip = "122.173.114.33";
