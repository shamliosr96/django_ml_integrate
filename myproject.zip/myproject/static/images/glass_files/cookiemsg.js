(function (window) {

    if (!!window.cookieChoices) {
        return window.cookieChoices;
    }

    var document = window.document;
    // IE8 does not support textContent, so we should fallback to innerText.
    var supportsTextContent = 'textContent' in document.body;

    var cookieChoices = (function () {

        var cookieName = 'displayCookieConsent';
        var cookieConsentId = 'cookieChoiceInfo';
        var dismissLinkId = 'cookieChoiceDismiss';
        var subDomainCookie = true;

        function _createHeaderElement(cookieTextPre, dismissText, cookieTextPost, linkText, linkHref) {
            var butterBarStyles = 'position:fixed; width:100%; border-top: 0px solid #ccc; background-color:#E6E6E6; color: #777; font-size: 12px;' +
          'margin:0; left:0; bottom:0; padding:10px 0; z-index:1000; text-align:center;';

            var cookieConsentElement = document.createElement('div');
            cookieConsentElement.id = cookieConsentId;
            cookieConsentElement.style.cssText = butterBarStyles;
            cookieConsentElement.appendChild(_createConsentText(cookieTextPre));

            if (!!linkText && !!linkHref) {
                cookieConsentElement.appendChild(_createInformationLink(linkText, linkHref));
            }
            cookieConsentElement.appendChild(_createConsentText(cookieTextPost));
            cookieConsentElement.appendChild(_createDismissLink(dismissText));
            return cookieConsentElement;
        }

        function _setElementText(element, text) {
            if (supportsTextContent) {
                element.textContent = text;
            } else {
                element.innerText = text;
            }
        }

        function _createConsentText(cookieText) {
            var consentText = document.createElement('span');
            _setElementText(consentText, cookieText);
            return consentText;
        }

        function _createDismissLink(dismissText) {
            var dismissLink = document.createElement('a');
            _setElementText(dismissLink, dismissText);
            dismissLink.id = dismissLinkId;
            dismissLink.href = '#';
            dismissLink.style.cssText = 'background-color:gray; color:#fff; padding: 5px; margin-left:10px; text-decoration: none;';
            return dismissLink;
        }

        function _createInformationLink(linkText, linkHref) {
            var infoLink = document.createElement('a');
            _setElementText(infoLink, linkText);
            infoLink.href = linkHref;
            infoLink.target = '_blank';
            infoLink.style.cssText = 'color:#777; text-decoration: underline; margin-left:5px;';
            return infoLink;
        }

        function _dismissLinkClick() {
            _saveUserPreference();
            _removeCookieConsent();
            return false;
        }

        function _showCookieConsent(cookieTextPre, dismissText, cookieTextPost, linkText, linkHref) {
            if (_shouldDisplayConsent()) {
                _removeCookieConsent();
                var consentElement = _createHeaderElement(cookieTextPre, dismissText, cookieTextPost, linkText, linkHref);
                var fragment = document.createDocumentFragment();
                fragment.appendChild(consentElement);
                document.body.appendChild(fragment.cloneNode(true));
                document.getElementById(dismissLinkId).onclick = _dismissLinkClick;
            }
        }

        function showCookieConsentBar(cookieTextPre, linkText, cookieTextPost, dismissText, linkHref) {
            _showCookieConsent(cookieTextPre, dismissText, cookieTextPost, linkText, linkHref);
        }

        function _removeCookieConsent() {
            var cookieChoiceElement = document.getElementById(cookieConsentId);
            if (cookieChoiceElement != null) {
                cookieChoiceElement.parentNode.removeChild(cookieChoiceElement);
            }
        }

        function _getDomainName() {
            var domain;
            var host = location.hostname;
            var domain_array = host.split('.');
            var domain_parts = domain_array.length;
            if (domain_parts == 2) domain = host;
            else {
                domain = domain_array[domain_parts - 2] + '.' + domain_array[domain_parts - 1];
            }
            return domain;
        }

        function _saveUserPreference() {
            // Set the cookie expiry to one year after today.
            var expiryDate = new Date();
            expiryDate.setFullYear(expiryDate.getFullYear() + 1);
            if (subDomainCookie) {
                document.cookie = cookieName + '=y; expires=' + expiryDate.toGMTString() + '; path=/; domain=' + _getDomainName();
            } else {
                document.cookie = cookieName + '=y; expires=' + expiryDate.toGMTString();
            }
        }

        function _shouldDisplayConsent() {
            // Display the header only if the cookie has not been set.
            return !document.cookie.match(new RegExp(cookieName + '=([^;]+)'));
        }

        var exports = {};
        exports.showCookieConsentBar = showCookieConsentBar;
        return exports;
    })();

    window.cookieChoices = cookieChoices;
    return cookieChoices;
})(this);
