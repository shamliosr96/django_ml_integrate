# def homepage(request):
#     return HttpResponse('<h1>welcome to my homepage</h1>')

# from myproject.myapp.templates.script import TestSplit
from django.shortcuts import render

# from myproject.myapp.script import TestSplit
# from myproject.myapp.script import TestSplit
# from script import TestSplit
from sklearn import preprocessing
import pandas as pd

# from myapp.script_heart import TestSplit
from scripts.new_wheat import TestSplitseed


def homepage(request):
    return render(request,'index.html')


from myapp.script import TestSplit


def home(request):
    msg = ''
    if request.method == 'POST':

        UserID = request.POST['UserID']

        Age = request.POST['Age']

        EstimatedSalary = request.POST['EstimatedSalary']

        Gender = request.POST['Gender']

        List = []

        List.append(Gender)
        List.append(Age)
        List.append(EstimatedSalary)

        # print(List)


        test = []

        # List.append(UserID)



        # label_encoder = preprocessing.LabelEncoder()
        # Gender=label_encoder.fit_transform(List)

        import numpy as np
        # List = np.array(test)
        # np.reshape(test,(-1,1))
        # label_encoder = preprocessing.LabelEncoder()
        # List[1]=label_encoder.fit_transform(List[1])



        test.append(List)

        # from myproject.templates.script import TestSplit


        print(test)
        # input()
        abc = TestSplit(test)
        # print(abc)





    return render(request,'home.html',locals())  # Locals(), we dont need to load variables everytime



def cancer(request):
    msg=''
    if request.method == 'POST':

        id = request.POST['id']

        clump_thickness   = request.POST['clump_thickness']

        uniform_cell_size = request.POST['uniform_cell_size']

        uniform_cell_shape = request.POST['uniform_cell_shape']

        marginal_adhesion = request.POST['marginal_adhesion']

        bare_nuclei = request.POST['bare_nuclei']

        bland_chromation = request.POST['bland_chromation']

        normal_nucleoli = request.POST['normal_nucleoli']

        mitoses = request.POST['mitoses']





        msg = "Successfully Enter the data ! Please wait Now for results"

        List = []
        test = []


        List.append(id)
        List.append(clump_thickness)
        List.append(uniform_cell_size)
        List.append(uniform_cell_shape)
        List.append(marginal_adhesion)
        List.append(bare_nuclei)
        List.append(bland_chromation)
        List.append(normal_nucleoli)
        List.append(mitoses)

        # print(List)




        test.append(List)
        # print("tttttttttttttttttttt",test)

        from myapp.script_breast_cancer import TestSplitcancer
        abc = TestSplitcancer(test)
        print("ffffffffffffff",abc)



    return render(request,'cancer.html',locals())



def wine(request):
        msg = ''
        if request.method == 'POST':



            Malic_acid = request.POST['Malic_acid']

            Ash = request.POST['Ash']

            Alcalinity_of_ash = request.POST['Alcalinity_of_ash']

            Magnesium = request.POST['Magnesium']

            Total_phenols = request.POST['Total_phenols']

            Flavanoids = request.POST['Flavanoids']

            Nonflavanoid = request.POST['Nonflavanoid']

            Proanthocyanins = request.POST['Proanthocyanins']

            Color_intensity = request.POST['Color_intensity']

            Hue = request.POST['Hue']

            diluted_wines = request.POST['diluted_wines']

            Proline = request.POST['Proline']

            msg = "Successfully Enter the data ! Please wait Now for results"

            List = []
            test = []


            List.append(Malic_acid)
            List.append(Ash)
            List.append(Alcalinity_of_ash)
            List.append(Magnesium)
            List.append(Total_phenols)
            List.append(Flavanoids)
            List.append(Nonflavanoid)
            List.append(Proanthocyanins)
            List.append(Color_intensity)
            List.append(Hue)
            List.append(diluted_wines)
            List.append(Proline)

            print(List)





            test.append(List)

            from myapp.script_wine import TestSplitwine
            abc = TestSplitwine(test)
            print("abc",abc)


        return render(request, 'wine.html', locals())



def wheat(request):
     msg = ''

     if request.method == 'POST':
           Area = request.POST['Area']
           Perimeter = request.POST['Perimeter']
           Compactness = request.POST['Compactness']
           Length_of_kernel = request.POST['Length_of_kernel']
           Width_of_kernel = request.POST['Width_of_kernel']
           Asymmetry_coefficient = request.POST['Asymmetry_coefficient']
           Length_of_kernel_groove = request.POST['Length_of_kernel_groove']



           msg = "Successfully Enter the data ! Please wait Now for results"


           List = []
           test = []
           List.append(Area)
           List.append(Perimeter)
           List.append(Compactness)
           List.append(Length_of_kernel)
           List.append(Width_of_kernel)
           List.append(Asymmetry_coefficient)
           List.append(Length_of_kernel_groove)

           print(List) 



           test.append(List)


           abc = TestSplitseed(test)
           print("abc",abc)

     return render(request, 'wheat.html', locals())




def teach(request):
    if request.method == 'POST':
        C= request.POST["Courseinstructor"]
        co = request.POST["Course"]

        SE = request.POST["Summer_or_regular_semester"]

        CS = request.POST["Class_size"]

        List = []
        test = []

        List.append(C)
        List.append(co)
        List.append(SE)
        List.append(CS)



        test.append(List)
        from myapp.teaching_script import TestSplitteach

        abcd = TestSplitteach(test)
        print("abc", abcd)

    return render(request, 'teach.html', locals())

















