import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn import preprocessing
from myproject.settings import BASE_DIR


def checkliver(newlist):
    df=pd.read_csv(BASE_DIR+'/Indian Liver Patient Dataset (ILPD).csv',header=None)

    empty_value = df.fillna(0,axis=1)

    x=empty_value.iloc[:,2:10]
    y=empty_value.iloc[:,-1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
    model = RandomForestClassifier()
    model.fit(x_train, y_train)
    joblib.dump(model, BASE_DIR+'/testliver.pkl')
    load = joblib.load(BASE_DIR+'/testliver.pkl')
    liverresult=load.predict(newlist)
    print(liverresult)


    return(liverresult)
