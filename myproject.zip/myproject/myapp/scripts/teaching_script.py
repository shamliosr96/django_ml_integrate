import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
import numpy as np
import pickle

from myproject.settings import BASE_DIR


def TestSplitteach(test):
    dataset = pd.read_csv(BASE_DIR+'/teaching aasitent evaluation.csv')
    X = dataset.iloc[:, 1:5]
    y = dataset.iloc[:,-1]
    # print(y)
    # input()

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    # pre=model.predict(X_test)
    # print(pre)

    joblib.dump(model, BASE_DIR+'/myapp/data/teach.pkl')

    data1 = joblib.load(BASE_DIR+'/myapp/data/teach.pkl')
    result=data1.predict(test)

    return result

