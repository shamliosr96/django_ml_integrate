import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

from myproject.settings import BASE_DIR
def Fpoker(Ptest):
    df=pd.read_csv(BASE_DIR+'/poker.csv')
    x=df.iloc[:,0:11]
    y=df.iloc[:,-1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=(0.3))
    model = RandomForestClassifier()
    model.fit(x_train, y_train)
    joblib.dump(model, BASE_DIR + '/myapp/data/poker.pkl')
    load = joblib.load(BASE_DIR + '/myapp/data/poker.pkl')
    Presult=load.predict(Ptest)
    return Presult