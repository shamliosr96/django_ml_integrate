import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
import numpy as np
import pickle

from myproject.settings import BASE_DIR


def TestSplitcancer(test):

    dataset = pd.read_csv(BASE_DIR+'/breast-cancer.csv')
    fgg=dataset.replace('?',0)
    # print(fgg)
    fgg.to_csv("gk.csv",index=None)

    X = fgg.iloc[:, 1:9]
    y = fgg.iloc[:, -1]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)

    joblib.dump(model,BASE_DIR+'/myapp/data/can.pkl')


    data1 =joblib.load(BASE_DIR+'/myapp/data/can.pkl')

    result = data1.predict(test)

    return result



