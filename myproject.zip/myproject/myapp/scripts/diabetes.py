import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

from myproject.settings import BASE_DIR


def diabetes2(outcome):
    df=pd.read_csv(BASE_DIR+"/diabetes.csv")
    x=df.iloc[:,0:7]
    y=df.iloc[:,-1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3)

    model = RandomForestClassifier()

    model.fit(x_train, y_train)


    joblib.dump(model,BASE_DIR+ '/testdiabte.pkl')
    data3 = joblib.load(BASE_DIR+'/testdiabte.pkl')

    result = data3.predict(outcome)
    print(result)
#
    return result