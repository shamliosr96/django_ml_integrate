from scipy.io import arff
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.externals import joblib
# from myproject.settings import BASE_DIR
from myproject.settings import BASE_DIR

def happy(Htest):
    df=pd.read_csv(BASE_DIR+'/happy.csv')
    a = df.dropna()
    x=a.iloc[:,1:7]
    y=a.iloc[:,0]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=(0.3))
    model = RandomForestClassifier()
    model.fit(x_train, y_train)
    joblib.dump(model, BASE_DIR + '/myapp/data/happy.pkl')
    load = joblib.load(BASE_DIR + '/myapp/data/happy.pkl')
    happyresult = load.predict(Htest)

    return happyresult


