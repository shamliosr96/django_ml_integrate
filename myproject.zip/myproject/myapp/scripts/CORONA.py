import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.externals import joblib




df=pd.read_csv('/home/webtunix/corona.csv')
a = df.dropna()
x=a.iloc[:,0:7]
y=a.iloc[:,-1]

Htest=[1,1,0,1,0,0,1]
count1 = Htest.count(1)
count0=Htest.count(0)
if count1>count0:
    print('Present')
elif count0>count1:
    print('Absent')

# print(count)
exit()
# x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=(0.2))
# model = RandomForestClassifier(n_estimators=10)
# model.fit(x_train, y_train)
# joblib.dump(model, '/home/webtunix/corona.pkl')
load = joblib.load('/home/webtunix/corona.pkl')
happyresult = load.predict(Htest)
print(happyresult)
if happyresult[0]==2:
    print('Corona_disease_present')
elif happyresult[0]==3:
    print('Corona_not_present')
