import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

import numpy as np

from myproject.settings import BASE_DIR


def TestSpli2(htest):
    df = pd.read_csv(BASE_DIR+"/heart_stalog.csv")
    # label_encoder = preprocessing.LabelEncoder()
    # df['Class'] = label_encoder.fit_transform(df['Class'])
    x = df.iloc[:, 3:13]
    y = df.iloc[:, -1]



    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
    # implementing kneighborsclassifier for prediction(0=absent,1=present)
    model = RandomForestClassifier()
    model.fit(x_train, y_train)




    joblib.dump(model, BASE_DIR+'/testheart.pkl')

    # file = open(', 'rb')
    data2 = joblib.load(BASE_DIR+'/testheart.pkl')
    # test=np.array(test)
    # np.reshape(test,(-1,1))
    result = data2.predict(htest)

    print(result)
    #
    #
    # testList = data1.predict(x_test,y_test)
    # print("=====")
    # print(testList)
    # print("=====")
    return result

