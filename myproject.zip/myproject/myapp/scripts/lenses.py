import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from myproject.settings import BASE_DIR

def reales(testh):
    df=pd.read_csv(BASE_DIR+'/Realestate.csv')
    x=df.iloc[:,2:7]
    y=df.iloc[:,-1]
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
    model=RandomForestRegressor()
    model.fit(x_train,y_train)
    joblib.dump(model,BASE_DIR+'/myapp/data/testestate.pkl')
    loader=joblib.load(BASE_DIR+'/myapp/data/testestate.pkl')
    result=loader.predict(testh)

    return result

