import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

from myproject.settings import BASE_DIR


def migration2(test):
    dataset = pd.read_csv('/home/webtunix/Documents/ss/myproject/myapp/scripts/mammogram_dataset.csv')
#print(dataset)
    X = dataset.iloc[:, :5]
    y = dataset.iloc[:, -1]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
# print(X_train)
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    joblib.dump(model, '/home/webtunix/Documents/ss/myproject/myapp/data/mammo.pkl')
    data1 = joblib.load('/home/webtunix/Documents/ss/myproject/myapp/data/mammo.pkl')
    result = data1.predict(test)
    return result




