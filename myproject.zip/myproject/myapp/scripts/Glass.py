import pandas as pd

from myproject.settings import BASE_DIR

df = pd.read_csv(BASE_DIR+'/glass.data')
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

def Fglass(out):
    x=df.iloc[:,1:10]
    y=df.iloc[:,-1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

    model = RandomForestClassifier()
    model.fit(x_train, y_train)

    joblib.dump(model,BASE_DIR+'/testGlass.pkl')

    RGlass= joblib.load(BASE_DIR+'/testGlass.pkl')

    result=RGlass.predict(out)
    print(result)


    return result