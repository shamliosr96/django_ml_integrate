import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from sklearn import model_selection
import pickle
import numpy as np
from sklearn import preprocessing

from myproject.settings import BASE_DIR


def TestSpli(test):
    df = pd.read_csv(BASE_DIR+"/Social_Network_Ads.csv")
    label_encoder = preprocessing.LabelEncoder()
    df['Gender'] = label_encoder.fit_transform(df['Gender'])
    x = df.iloc[:, 2:4]
    y = df.iloc[:, -1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
    # implementing kneighborsclassifier for prediction(0=absent,1=present)
    model = RandomForestClassifier()
    model.fit(x_train, y_train)


    # with open(l', 'wb') as handle:
    #     pickle.dump(y_pred, handle)
    # file = open('/home/chandni/PycharmProjects/project1/myproject/myapp/data/test.pkl', 'rb')
    # data1 = pickle.load(file)
    # y_score=data1.model_score(x_test,y_test)
    # print(y_score)

    joblib.dump(model,BASE_DIR+ '/test.pkl')

    # file = open(', 'rb')
    data1 = joblib.load(BASE_DIR+'/test.pkl')
    test=np.array(test)
    np.reshape(test,(-1,1))
    result = data1.predict(test)


    #
    #
    # testList = data1.predict(x_test,y_test)
    # print("=====")
    # print(testList)
    # print("=====")
    return result
# TestSpli()